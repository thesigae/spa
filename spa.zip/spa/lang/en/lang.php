<?php return [
    'plugin' => [
        'name' => 'Spa',
        'description' => 'For creating single page applications.'
    ]
];